package br.com.voidstar.personCompany;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

public class Company {
    private String name;
    private Workforce workforce;


    public Company() {
        this.name = "";
    }

    public Company(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWorkforce(Workforce workforce) {
        this.workforce = workforce;
    }

    public int getNumberOfEmployees() {
        // Verifica se a força de trabalho está atribuída antes de acessar
        return (workforce != null) ? workforce.getNumberOfEmployees(this) : 0;
    }

    public void hire(Person person, double salary) {
        if (workforce != null) {
            workforce.hire(this, person, salary);
        } else {
            throw new IllegalStateException("Workforce not assigned to Company");
        }
    }

    public void dismiss(Person person) {
        if (workforce != null) {
            workforce.dismiss(this, person);
        }
    }

    public boolean employed(Person person) {
        return workforce != null && workforce.employed(person, this);
    }

    public double payroll() {
        return workforce != null ? workforce.payroll(this) : 0.0;
    }
}
