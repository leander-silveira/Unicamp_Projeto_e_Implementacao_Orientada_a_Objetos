package br.com.voidstar.personCompany;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Workforce {
	private Set<Contract> contracts = new HashSet<>();

    public Workforce() {
    	
    }

    private HashSet<Contract> getContractsPerson(Person person) {
        HashSet<Contract> personContracts = new HashSet<>();
        for (Contract contract : contracts) {
            if (contract.getEmployee().equals(person)) {
                personContracts.add(contract);
            }
        }
        return personContracts;
    }

    private HashSet<Contract> getContractsCompany(Company company) {
        HashSet<Contract> companyContracts = new HashSet<>();
        for (Contract contract : contracts) {
            if (contract.getEmployer().equals(company)) {
                companyContracts.add(contract);
            }
        }
        return companyContracts;
    }

    public boolean employed(Person person, Company company) {
        for (Contract contract : contracts) {
            if (contract.getEmployee().equals(person) && contract.getEmployer().equals(company)) {
                return true;
            }
        }
        return false;        
    }

    public void hire(Company company, Person person, double salary) {
        // Verifica se a pessoa já está empregada na empresa para evitar múltiplos contratos
        if (!employed(person, company)) {
            Contract contract = new Contract(company, person, salary);
            contracts.add(contract);
        }
    }

    public void dismiss(Company company, Person person) {
        // Remove o contrato específico entre a pessoa e a empresa
        Iterator<Contract> iterator = contracts.iterator();
        while (iterator.hasNext()) {
            Contract contract = iterator.next();
            if (contract.getEmployer().equals(company) && contract.getEmployee().equals(person)) {
                iterator.remove();
            }
        }
    }

    public double getSalary(Person person) {
        // Calcula o salário total da pessoa considerando múltiplos contratos
        double totalSalary = 0.0;
        for (Contract contract : contracts) {
            if (contract.getEmployee().equals(person)) {
                totalSalary += contract.getSalary();
            }
        }
        return totalSalary;
    }

    public double payroll(Company company) {
        // Calcula o custo total da folha de pagamentos da empresa
        double totalPayroll = 0.0;
        for (Contract contract : contracts) {
            if (contract.getEmployer().equals(company)) {
                totalPayroll += contract.getSalary();
            }
        }
        return totalPayroll;
    }

    public int getNumberOfEmployees(Company company) {
        // Retorna o número de contratos ativos da empresa
        return getContractsCompany(company).size();
    }

}
