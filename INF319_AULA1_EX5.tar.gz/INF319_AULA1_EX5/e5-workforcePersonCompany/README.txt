Person and Company classes are used to exemplify different object-oriented designs for relationships.
