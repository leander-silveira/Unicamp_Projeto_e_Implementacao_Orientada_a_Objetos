package br.com.voidstar.personCompany;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Company {
    private String name;
    private Set<Person> employees;

    public Company() {
        this.name = "";
        this.employees = new HashSet<>();
    }

    public Company(String name) {
        this.name = name;
        this.employees = new HashSet<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
    	this.name = name;
    }

    public int getNumberOfEmployees() {
        return employees.size();
    }

    public void hire(Person person, double salary) {
        if (person.getSalary() == 0.0 && salary > 0.0) {
            person.setSalary(salary);
            employees.add(person);
        }
    }

    public void dismiss(Person person) {
        if (person.getSalary() > 0.0 && employees.contains(person)) {
            person.setSalary(0.0);
            employees.remove(person);
        }
    }

    public double payroll() {
        double totalPayroll = 0.0;
        for (Person employee : employees) {
            totalPayroll += employee.getSalary();
        }
        return totalPayroll;
    }
}
