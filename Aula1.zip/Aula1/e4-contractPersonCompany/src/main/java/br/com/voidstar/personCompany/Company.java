package br.com.voidstar.personCompany;

import java.util.HashMap;
import java.util.Map;

public class Company {
    private String name;
    private Map<Person, Contract> contracts = new HashMap<>();

    public Company() {
        this.name = "";
    }

    public Company(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberOfEmployees() {
        return contracts.size();
    }
    
    protected void hire(Contract contract) {
        contracts.put(contract.getPerson(), contract);
    }

    protected void dismiss(Contract contract) {
        contracts.remove(contract.getPerson());
    }

    public void hire(Person person, double salary) {
        // Evita múltiplos contratos ao garantir que a pessoa seja demitida de outro emprego antes de ser contratada
        if (person.getCompany() != null && person.getCompany() != this) {
            person.getCompany().dismiss(person);
        }
        
        if (!contracts.containsKey(person)) {
            Contract contract = new Contract(this, person, salary);
            hire(contract);
            person.selfHire(contract);
        }
    }

    public void dismiss(Person person) {
        if (contracts.containsKey(person)) {
            Contract contract = contracts.get(person);
            person.selfDismiss(contract);
            dismiss(contract);
        }
    }

    public boolean employed(Person person) {
        // it supposes uniqueness of persons (objects).
        return contracts.containsKey(person);

    }

    public double payroll() {
        double totalPayroll = 0.0;
        for (Contract contract : contracts.values()) {
            totalPayroll += contract.getSalary();
        }
        return totalPayroll;
        }
}
