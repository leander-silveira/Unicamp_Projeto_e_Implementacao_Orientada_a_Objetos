package br.com.voidstar.personCompany;

public class Person {
	private String firstName;
	private String surName;
	private double salary;
	private Company company;

    public Person() {
    	this.firstName = "";
    	this.surName = "";
    	this.salary = 0;
    	this.company = null;
    }

    public Person(String name, String surname) {
    	this.firstName = name;
    	this.surName = surname;
    }
    
    public Person(String name, String surname, double salary, Company company) {
    	this.firstName = name;
    	this.surName = surname;
    	this.salary = salary;
    	this.company = company;
    	if(company != null) {
    		company.incrementNumberOfEmployees();
    	}

    }
    public String getName() {
    	return firstName;
    }
    public void setName(String name) {
    	this.firstName = name;
    }

    public String getSurname() {
    	return surName;
    }

    public void setSurname(String surname) {
    	this.surName = surname;
    }

    public double getSalary() {
    	return salary;
    }

    public Company getCompany() {
    	return company;
    }

    public void selfHire(Company company, double salary) {
    	if(this.company == null && company != null) {
    		this.company = company;
    		this.salary = salary;
    		company.incrementNumberOfEmployees();
    	} else {
    		System.out.println("já está empregado(a)");
    	}
    }

    public void selfDismiss() {
    	if(this.company != null) {
    		this.company.decrementNumberOfEmployees();
    		this.company = null;
    		this.salary = 0;
    	} else {
    		System.out.println("não está empregado(a)");
    	}
    }
}
