package br.com.voidstar.personCompany;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

public class CompanyPersonTest {
    private static Company ca, cb, cc;
    private static Person pa, pb,pc;
    private static Workforce workforce;

    @Before
    public void setUp() throws Exception {

        workforce = new Workforce();

        ca = new Company();
        ca.setWorkforce(workforce);
        cb = new Company("CB");
        cb.setWorkforce(workforce);
        cc = new Company("CC");
        cc.setWorkforce(workforce);

        pa = new Person("A", "AA");
        pa.setWorkforce(workforce);
        pb = new Person("B", "BB");
        pb.setWorkforce(workforce);
        pc = new Person("C", "CC");
        pc.setWorkforce(workforce);
    }

    @After
    public void tearDown() throws Exception {
        // No action necessary here.
    }

    @Test
    public void test() {
        // Test the state of ca after its construction.
        assertEquals(ca.getName(), "");
        assertEquals(ca.getNumberOfEmployees(), 0);
        assertEquals(ca.payroll(), 0.0, 0.0);

        // Test the state of cb after its construction.
        assertEquals(cb.getName(), "CB");
        assertEquals(cb.getNumberOfEmployees(), 0);
        assertEquals(cb.payroll(), 0.0, 0.0);

        // Test construction of cc
        assertEquals(cc.getName(), "CC");
        assertEquals(cc.getNumberOfEmployees(), 0);

        cc.setName("Sucupira");
        assertEquals(cc.getName(), "Sucupira");
        assertEquals(cc.payroll(), 0.0, 0.0);

        cc.hire(pa, 1000.0);
        assertEquals(cc.getNumberOfEmployees(), 1);
        assertEquals(cc.payroll(), 1000.0, 0.0);
        cc.hire(pb, 1100.0);
        assertEquals(cc.payroll(), 2100.00, 0.0);
        cc.hire(pc, 1200.0);
        assertEquals(cc.payroll(), 3300.0, 0.0);
        assertEquals(cc.getNumberOfEmployees(), 3);
        assertTrue(cc.employed(pa));
        assertTrue(cc.employed(pb));
        assertTrue(cc.employed(pc));

        // PA finds an additional job at CA
        // PA now holds two jobs, at CC and CA
        ca.hire(pa, 1000.0);
        assertEquals(ca.payroll(), 1000.0, 0.0);
        assertEquals(ca.getNumberOfEmployees(), 1);
        assertTrue(cc.employed(pa));
        assertTrue(ca.employed(pa));
        assertEquals(pa.getSalary(), 2000.00, 0.0);


        pa.selfHire(ca, 2000.00);
        assertEquals(pa.getSalary(), 2000.00, 0.0);
        assertTrue(ca.employed(pa));
        ca.hire(pa, 1500.00);
        // a person cannot maintain more than one contract with a
        // company. In this case selfHire and hire do not go through
        // with the hiring.
        assertNotEquals(pa.getSalary(), 1500.00, 0.0);
        // PA dismisses herself
        pa.selfDismiss(ca);
        assertFalse(ca.employed(pa));
        // CA hires PA back with a bigger salary
        ca.hire(pa, 3000.00);
        assertEquals(ca.payroll(), 3000.00, 0.0);
        ca.hire(pb, 2000.00);
        assertEquals(ca.payroll(), 5000.00, 0.0);
        // a person cannot be hired twice in the same Company
        ca.hire(pb, 2500.00);
        assertEquals(ca.payroll(), 5000.00, 0.0);
        ca.hire(pc, 5000.00);
        assertEquals(ca.payroll(), 10000.00, 0.0);
        // a company can dismiss a person
        ca.dismiss(pa);
        // a person can dismiss itself, if employed.
        pa.selfDismiss(ca);

        // a person can dismiss itself, if employed
        pb.selfDismiss(ca);
        // a company can dismiss a person, if the person is employed at the company
        // otherwise dismissal is a no-op.
        ca.dismiss(pb);
        // Dismissal of a non-employee is a no-op.
        ca.dismiss(pb);
        assertFalse(ca.employed(pb));
        ca.hire(pb, 1000.00);
        // PB earns 1100.00 from CC and 1000.00 from CA
        assertEquals(pb.getSalary(), 2100.00, 0.0);
        // CA has now a 6000.00 payroll cost
        assertEquals(ca.payroll(), 6000.00, 0.0);
    }
}
