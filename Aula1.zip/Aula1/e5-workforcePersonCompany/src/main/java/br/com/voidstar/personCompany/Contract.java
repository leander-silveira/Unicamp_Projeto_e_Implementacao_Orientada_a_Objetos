package br.com.voidstar.personCompany;

public class Contract {

    private Company employer;
    private Person employee;
    private double salary;

    public Contract(Company employer, Person employee, double salary) {
        this.employer = employer;
        this.employee = employee;
        this.salary = salary;
    }

    public Company getEmployer() {
        return employer;
    }

    public Person getEmployee() {
        return employee;
    }

    public double getSalary() {
        return salary;
    }
}
