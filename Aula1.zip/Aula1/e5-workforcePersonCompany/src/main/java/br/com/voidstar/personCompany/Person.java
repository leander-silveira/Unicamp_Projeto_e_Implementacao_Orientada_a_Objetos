package br.com.voidstar.personCompany;

public class Person {
    private String name = "";
    private String surname = "";
    private Workforce workforce;

    public Person() {
        name = "";
        surname = "";
    }

    public Person(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }
    public Person(String name, String surname, double salary, Company company) {
        this.name = name;
        this.surname = surname;
        selfHire(company, salary);
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public double getSalary() {
        return workforce != null ? workforce.getSalary(this) : 0.0;
    }

    public void setWorkforce(Workforce workforce) {
        this.workforce = workforce;
    }


    public void selfHire(Company company, double salary) {
        if (workforce != null) {
            workforce.hire(company, this, salary);
        }
    }

    public void selfDismiss(Company company) {
        if (workforce != null) {
            workforce.dismiss(company, this);
        }
    }
}
