package inf319;

/**
 * Esta classe implementa a cafeteira Harar.
 */ 

public class Harar_Cafeteira {
    public static void main(String[] args) {
        // Cria os componentes da cafeteira
        Hardware oHardware = new Hardware();
        Cafeteira aCafeteira = new Cafeteira();

        Harar_ControladorAquecedor controladorAquecedor =
            new Harar_ControladorAquecedor(oHardware);
        Harar_ControladorVaporizador controladorVaporizador =
            new Harar_ControladorVaporizador(oHardware);
        Harar_ControladorIHC controladorIHC =
            new Harar_ControladorIHC(oHardware);

        Harar_Aquecedor aquecedor =
            new Harar_Aquecedor(controladorAquecedor, aCafeteira);
        Harar_Vaporizador vaporizador =
            new Harar_Vaporizador(controladorVaporizador, aCafeteira);
        Harar_IHC ihc = new Harar_IHC(controladorIHC, aCafeteira);

        // Liga os componentes ao modulo de controle
        aCafeteira.ajustaIHC(ihc);
        aCafeteira.ajustaVaporizador(vaporizador);
        aCafeteira.ajustaAquecedor(aquecedor);

        
        //////////////////////////////////////////////////////////////////
        // Executa a cafeteira

        // Inicia o hardware
        oHardware.iniciar();

        // Executa o software de controle
        while (true) {
        	    try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}       	    
            ihc.verifica();
            vaporizador.verifica();
            aquecedor.verifica();
        }
    }
}
