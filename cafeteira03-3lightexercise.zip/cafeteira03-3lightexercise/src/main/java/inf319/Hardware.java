package inf319;

/**
 * Classe que implementa a interface e encarna o 'hardware' da cafeteira.
 */
public class Hardware {

    // Estados dos componentes do hardware
    private EstadoHardware estadoAquecedor;
    private EstadoHardware estadoEbulidor;
    private EstadoHardware estadoInterruptor;
    private EstadoHardware estadoElementoEbulidor;
    private EstadoHardware estadoElementoAquecedor;
    private EstadoHardware estadoLuzIndicadora;
    private EstadoHardware estadoValvulaPressao;
    private int nivelDeAgua; // Novo atributo para representar o nível de água
    private int nivelDeCafe; // Novo atributo para representar o nível de café

    // Adicionando enum para estados da luz indicadora
    public enum CorLuz {
        VERMELHO, // Cafeteira em espera, sem café e sem água
        AMARELO,  // Café em processo de coação
        VERDE     // Café pronto para consumo
    }

    private CorLuz corLuzIndicadora;

    public Hardware() {
        this.estadoLuzIndicadora = EstadoHardware.DESLIGADO;
        this.corLuzIndicadora = CorLuz.VERMELHO; // Estado inicial
        this.nivelDeAgua = 0; // Inicializando o nível de água como zero
        this.nivelDeCafe = 0; // Inicializando o nível de café como zero
    }

    /**
     * Inicializa o hardware, configurando os estados iniciais.
     */
    public void iniciar() {
        this.estadoAquecedor = EstadoHardware.aquecedorDesligado;
        this.estadoEbulidor = EstadoHardware.ebulidorDesligado;
        this.estadoInterruptor = EstadoHardware.interruptorSolto;
        this.estadoElementoEbulidor = EstadoHardware.ebulidorVazio;
        this.estadoElementoAquecedor = EstadoHardware.placaVazia;
        this.estadoLuzIndicadora = EstadoHardware.indicadoraDesligada;
        this.estadoValvulaPressao = EstadoHardware.valvulaFechada;
    }

    /**
     * Atualiza o estado da luz indicadora com base nos estados dos componentes.
     */
    public void atualizarLuzIndicadora(boolean temAgua, boolean cafePronto, boolean emProcesso) {
        if (!temAgua && !cafePronto && !emProcesso) {
            corLuzIndicadora = CorLuz.VERMELHO;
        } else if (emProcesso) {
            corLuzIndicadora = CorLuz.AMARELO;
        } else if (cafePronto) {
            corLuzIndicadora = CorLuz.VERDE;
        }
    }

    /**
     * Retorna a cor atual da luz indicadora.
     */
    public CorLuz getCorLuzIndicadora() {
        return corLuzIndicadora;
    }

    /**
     * Liga ou desliga a luz indicadora.
     */
    public void ligarLuzIndicadora() {
        this.estadoLuzIndicadora = EstadoHardware.LIGADO;
    }

    public void desligarLuzIndicadora() {
        this.estadoLuzIndicadora = EstadoHardware.DESLIGADO;
    }

    /**
     * Retorna o estado atual da luz indicadora.
     */
    public EstadoHardware getEstadoLuzIndicadora() {
        return estadoLuzIndicadora;
    }

    /**
     * Ajusta o nível de água.
     */
    public void ajustaNivelDeAgua(int nivel) {
        this.nivelDeAgua = nivel;
    }

    /**
     * Retorna o nível atual de água.
     */
    public int pegaNivelDeAgua() {
        return this.nivelDeAgua;
    }

    /**
     * Ajusta o nível de café.
     */
    public void ajustaNivelDeCafe(int nivel) {
        this.nivelDeCafe = nivel;
    }

    /**
     * Retorna o nível atual de café.
     */
    public int pegaNivelDeCafe() {
        return this.nivelDeCafe;
    }

    /**
     * Coloca a jarra na cafeteira.
     */
    public void colocaJarra() {
        this.estadoValvulaPressao = EstadoHardware.valvulaFechada;
    }

    /**
     * Remove a jarra da cafeteira.
     */
    public void removeJarra() {
        this.estadoValvulaPressao = EstadoHardware.valvulaAberta;
    }

    /**
     * Método preexistente preservado para manter compatibilidade com outras classes.
     */
    public void atuValvulaPressao(EstadoHardware estado) {
        this.estadoValvulaPressao = estado;
    }

    /**
     * Método preexistente para alterar o estado do elemento ebulidor.
     */
    public void atuEstadoElementoEbulidor(EstadoHardware estado) {
        this.estadoElementoEbulidor = estado;
    }

    /**
     * Método preexistente para alterar o estado do aquecedor.
     */
    public void atuEstadoAquecedor(EstadoHardware estado) {
        this.estadoAquecedor = estado;
    }

    /**
     * Método para leitura do estado do ebulidor.
     */
    public EstadoHardware leEstadoEbulidor() {
        return estadoEbulidor;
    }

    /**
     * Método para leitura do estado do aquecedor.
     */
    public EstadoHardware leEstadoAquecedor() {
        return estadoAquecedor;
    }

    /**
     * Método para leitura do estado da luz indicadora.
     */
    public EstadoHardware leEstadoLuzIndicadora() {
        return estadoLuzIndicadora;
    }

    /**
     * Método para leitura do estado do elemento ebulidor.
     */
    public EstadoHardware leEstadoElementoEbulidor() {
        return estadoElementoEbulidor;
    }

    /**
     * Método para leitura do estado do elemento aquecedor.
     */
    public EstadoHardware leEstadoElementoAquecedor() {
        return estadoElementoAquecedor;
    }

    /**
     * Método para leitura do estado da válvula de pressão.
     */
    public EstadoHardware leEstadoValvulaPressao() {
        return estadoValvulaPressao;
    }

    /**
     * Método para leitura do estado do interruptor.
     */
    public EstadoHardware leEstadoInterruptor() {
        return estadoInterruptor;
    }

    /**
     * Método para alterar o estado do elemento aquecedor.
     */
    public void atuElementoAquecedor(EstadoHardware estado) {
        this.estadoElementoAquecedor = estado;
    }

    /**
     * Método para alterar o estado da luz indicadora.
     */
    public void atuLuzIndicadora(EstadoHardware estado) {
        this.estadoLuzIndicadora = estado;
    }

    /**
     * Método para simular o pressionamento de um botão no hardware.
     */
    public void pressionaBotao() {
        this.estadoInterruptor = EstadoHardware.interruptorPressionado;
    }
}
