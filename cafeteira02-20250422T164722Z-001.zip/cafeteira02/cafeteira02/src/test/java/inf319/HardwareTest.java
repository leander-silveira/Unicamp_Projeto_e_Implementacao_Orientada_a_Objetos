package inf319;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HardwareTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
//		fail("Se necessário, implemente um teste para o Hardware/Cafeteira.");
	}

}
