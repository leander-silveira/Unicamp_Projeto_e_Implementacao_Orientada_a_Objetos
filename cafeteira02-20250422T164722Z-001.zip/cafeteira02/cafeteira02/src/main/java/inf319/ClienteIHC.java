package inf319;

/** 
 * Interface para um cliente genérico da IHC.
 */
public interface ClienteIHC {
    public void fazerCafe();
    public boolean checaPronto();
}
