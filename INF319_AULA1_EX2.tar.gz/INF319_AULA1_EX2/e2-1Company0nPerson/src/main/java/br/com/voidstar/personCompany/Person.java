package br.com.voidstar.personCompany;

public class Person {
    private String firstName;
    private String surName;
    private double salary;
    
    public Person() {
        this.firstName = "";
        this.surName = "";
        this.salary = 0.0;
    }
    
    public Person(String name, String surname) {
        this.firstName = name;
        this.surName = surname;
        this.salary = 0.0;
    }
    
    public String getName() {
        return firstName;
    }
    
    public void setName(String name) {
        this.firstName = name;
    }
    
    public String getSurname() {
        return surName;
    }
    
    public void setSurname(String surname) {
        this.surName = surname;
    }
    
    protected void setSalary(double salary) {
        if ((this.salary == 0.0 && salary > 0.0) || (this.salary > 0.0 && salary == 0.0)) {
            this.salary = salary;
        }
    }
    
    public double getSalary() {
        return salary;
    }
}
