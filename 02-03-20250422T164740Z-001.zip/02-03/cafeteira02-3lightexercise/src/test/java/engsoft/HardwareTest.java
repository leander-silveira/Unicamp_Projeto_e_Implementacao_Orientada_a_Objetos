package engsoft;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import inf319.EstadoHardware;
import inf319.Hardware;

public class HardwareTest {

	@Before
	public void setUp() throws Exception {
		System.setProperty("java.awt.headless", "true");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
//		fail("Se necessário, implemente um teste para o Hardware/Cafeteira.");
	}

	



}
