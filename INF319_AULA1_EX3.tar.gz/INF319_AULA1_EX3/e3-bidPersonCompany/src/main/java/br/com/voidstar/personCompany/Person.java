package br.com.voidstar.personCompany;

public class Person {
    private String name;
    private String surname;
    private double salary;
    private Company company;
    
    public Person() {
        this.name = "";
        this.surname = "";
        this.salary = 0.0;
        this.company = null;
    }

    public Person(String name, String surname) {
        this.name = name;
        this.surname = surname;
        this.salary = 0.0;
        this.company = null;
    }
    
    public Person(String name, String surname, double salary, Company company) {
        this.name = name;
        this.surname = surname;
        this.salary = salary;
        this.company = null; // Inicializa como null antes de contratar
        if (company != null) {
            company.hire(this, salary);
        }
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return this.surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public double getSalary() {
        return this.salary;
    }
    
    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Company getCompany() {
        return this.company;
    }
    
    public void setCompany(Company company) {
        this.company = company;
    }

    public void selfHire(Company company, double salary) {
        if (this.company != company) {
            if (this.company != null) {
                this.company.dismiss(this);
            }
            company.hire(this, salary); // Contratação direta pela empresa
        }
    }

    public void selfDismiss(Company company) {
        if (this.company == company) {
            company.dismiss(this); // Demissão direta pela empresa
        }
        }
 }

