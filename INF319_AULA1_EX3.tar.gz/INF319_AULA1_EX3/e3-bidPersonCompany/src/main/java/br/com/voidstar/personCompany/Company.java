package br.com.voidstar.personCompany;

import java.util.HashSet;
import java.util.Set;
public class Company {
    private String name;
    private Set<Person> employees;
        
    public Company() {
        this.name = "";
        this.employees = new HashSet<>();
    }

    public Company(String name) {
        this.name = name;
        this.employees = new HashSet<>();
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberOfEmployees() {
        return employees.size();
    }

    public void hire(Person person, double salary) {
        // Se a pessoa já está empregada em outra companhia, demita-a antes de contratá-la
        if (person.getCompany() != null && person.getCompany() != this) {
            person.getCompany().dismiss(person);
        }
        
        // Se a pessoa já está na lista de empregados, não atualize o salário
        if (!employees.contains(person)) {
            employees.add(person);
            person.setCompany(this); // Define a nova empresa da pessoa
            person.setSalary(salary); // Define o salário da pessoa
        }
    }

    public void dismiss(Person person) {
        // Remove a pessoa da lista de empregados e redefine o salário e a companhia dela
        if (employees.contains(person)) {
            employees.remove(person);
            person.setCompany(null);
            person.setSalary(0.0);
        }
    }

    public boolean employed(Person person) {
        return employees.contains(person);
    }

    public double payroll() {
        double totalPayroll = 0.0;
        for (Person person : employees) {
            totalPayroll += person.getSalary();
        }
        return totalPayroll;
    }
}
