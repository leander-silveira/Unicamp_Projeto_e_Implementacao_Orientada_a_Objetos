package engsoft;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import inf319.EstadoHardware;
import inf319.Hardware;

public class HardwareTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
	    // Simula o hardware sem inicializar a GUI
	    Hardware hardware = new Hardware();

	    // Testa os estados do indicador de luz
	    hardware.atuLuzIndicadora(EstadoHardware.indicadoraVermelha);
	    assertEquals(EstadoHardware.indicadoraVermelha, hardware.leEstadoLuzIndicadora());

	    hardware.atuLuzIndicadora(EstadoHardware.indicadoraAmarela);
	    assertEquals(EstadoHardware.indicadoraAmarela, hardware.leEstadoLuzIndicadora());

	    hardware.atuLuzIndicadora(EstadoHardware.indicadoraVerde);
	    assertEquals(EstadoHardware.indicadoraVerde, hardware.leEstadoLuzIndicadora());
	}
	

}
