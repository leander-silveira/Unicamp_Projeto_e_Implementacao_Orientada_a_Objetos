package inf319;

/**
 * Esta classe implementa a interface ControladorIHC para
 * o hardware da cafeteira Harar.
 */
public class Harar_ControladorIHC implements ControladorIHC {
    
    private Hardware cafeteiraCafeBB;

    public Harar_ControladorIHC(Hardware oHardware) {
        cafeteiraCafeBB = oHardware;
    }

    public void indicaFim() {
        cafeteiraCafeBB.atuLuzIndicadora(EstadoHardware.indicadoraLigada);
    }

    public void indicaPronto() {
        cafeteiraCafeBB.atuLuzIndicadora(EstadoHardware.indicadoraDesligada);
        cafeteiraCafeBB.atuLuzIndicadora(EstadoHardware.indicadoraVerde);
    }

    public void indicaCoacao() { 
    	cafeteiraCafeBB.atuLuzIndicadora(EstadoHardware.indicadoraCoacao);
        cafeteiraCafeBB.atuLuzIndicadora(EstadoHardware.indicadoraAmarela);  	
    }
    

    public boolean checaInicio() {
        return cafeteiraCafeBB.leEstadoInterruptor().equals(
                EstadoHardware.interruptorPressionado);
    }
    
    public void indicaEspera() {
        cafeteiraCafeBB.atuLuzIndicadora(EstadoHardware.indicadoraVermelha);
    }
}
