package inf319;

/**
 * Classe abstrata que apresenta a interface de um aquecedor de uma
 * cafeteira. O aquecedor informa se está pronto para começar a fazer
 * café e é informado que a confecção do café terminou.
 * 
 * 
 * Analisado os códigos 02-03 e 03-03 nos termos de estrutura e modularidade, complexidade da adaptação
 * e reutilização/flexibilidade
 * 
 * 
 * Código 02-03
 * Estrutura e Modularidade -> O código 02-03 é estruturado com classes que têm responsabilidades bem definidas. A lógica da luz indicadora está espalhada em várias classes, como Hardware, IHC, e JanelaCafeteira. Isso aumenta o acoplamento e torna difícil entender o impacto das alterações.
 * Complexidade da Adaptação -> A inclusão das novas cores da luz indicadora exigiu mudanças em:
 * EstadoHardware (adicionados novos estados de cores).
 * Hardware (modificação do método atuLuzIndicadora).
 * IHC (adaptação para usar as novas cores em estados específicos).
 * JanelaCafeteira (alteração do método atualizaEstado para refletir as novas cores na interface gráfica).
 * O impacto foi considerável, exigindo alterações em várias classes interdependentes.
 * Reutilização e Flexibilidade -> O código depende fortemente de alterações diretas em métodos específicos, o que pode dificultar a inclusão de mais estados de luz ou funcionalidades adicionais no futuro.
 * 
 * 
 * Código 03-03
 * Estrutura e Modularidade -> O código 03-03 faz um uso mais rigoroso de abstrações, como interfaces (ControladorIHC, ClienteIHC, etc.) e classes especializadas para controle (Harar_ControladorIHC). Isso promove uma maior separação de responsabilidades.
 * Complexidade da Adaptação -> A implementação das novas cores da luz indicadora exigiu alterações em:
 * EstadoHardware (adicionados novos estados).
 * Harar_ControladorIHC (controle direto das cores no método indicaEspera, indicaCoacao, etc.).
 * Nenhuma mudança no hardware base foi necessária, já que o comportamento da luz foi tratado no controlador.
 * O impacto foi menor devido ao isolamento das mudanças no controlador específico.
 * Reutilização e Flexibilidade -> O código facilita a inclusão de novos estados ou comportamentos específicos, pois as alterações podem ser localizadas no controlador especializado (Harar_ControladorIHC), sem afetar o restante do sistema.
 * 
 * 
 * O código 03-03 foi mais fácil de manter e adaptar. Ele apresenta uma maior modularidade, separando a lógica do controle específico no controlador (Harar_ControladorIHC), o que minimizou o impacto da mudança no restante do código.
 * Essa estrutura facilita futuras alterações e reduz a possibilidade de erros durante a adaptação.
 * 
 * 
 * 
 * 
 * 
 */
public abstract class Aquecedor {
    
    private ControladorAquecedor controlador;
    private ClienteAquecedor cliente;

    public Aquecedor(ControladorAquecedor oControlador, 
                     ClienteAquecedor oCliente) {
        controlador = oControlador;
        cliente = oCliente;
    }

    // Estimulos externos
    public abstract void fazerCafe();
    public abstract void cafeFeito();
    public abstract boolean checaPronto();

    // Interface para as subclasses
    protected ControladorAquecedor obterControlador() {
        return controlador;
    }

    protected ClienteAquecedor obterCliente() {
        return cliente;
    }
}
