package inf319;


/**
 * Esta classe é o centro da comunicação entre o aquecedor, vaporizador e
 * IHC. Ela implementa todas as três interfaces de clientes e direciona
 * as mensagens entre estas abstrações.
 */
public class Cafeteira 
        implements ClienteVaporizador, ClienteAquecedor, ClienteIHC {
    
    private IHC ihc;
    private Aquecedor aquecedor;
    private Vaporizador vaporizador;

    public Cafeteira() {
        ihc = null;
        aquecedor = null;
        vaporizador = null;
    }

    // ClienteIHC
    public boolean checaPronto() {
        return aquecedor.checaPronto() && vaporizador.checaPronto();
    }

    public void fazerCafe() {
        aquecedor.fazerCafe();
        vaporizador.fazerCafe();
    }

    // ClienteVaporizador
    public void cafeFeito() {
        ihc.cafeFeito();
        aquecedor.cafeFeito();
    }

    // ClienteAquecedor
    public void jarra() {
        vaporizador.jarra();
    }

    public void semJarra() {
        vaporizador.semJarra();
    }

    public void cicloCompleto() {
        ihc.cicloCompleto();
    }

    // Métodos para 'montar' a cafeteira. 
    public void configurarIHC(IHC novoIHC) {
        ihc = novoIHC;
    }

    public void configurarAquecedor(Aquecedor novoAquecedor) {
        aquecedor = novoAquecedor;
    }

    public void configurarVaporizador(Vaporizador novoVaporizador) {
        vaporizador = novoVaporizador;
    }
}

