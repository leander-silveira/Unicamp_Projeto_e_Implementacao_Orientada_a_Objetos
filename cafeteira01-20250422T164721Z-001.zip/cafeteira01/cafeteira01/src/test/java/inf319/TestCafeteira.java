package inf319;


import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;

public class TestCafeteira {
	
	private static Hardware h;
	private static Cafeteira c;
		
	@BeforeClass
	public static void setUp() {
        // neste método a cafeteira é iniciada desacoplada da IHC.
        // emula-se o pressionar do botão LIGA
        // verifica-se que o estado da Cafeteira é o esperado
        // após o acionamento do botão LIGA.

	}

	@Test
	public void normalFlow() {
    // Neste método testa-se o fluxo de execução normal da Cafeteira
    // Nível inicial de água deve ser 15

    }
	
	@Test
	public void exceptionalFlow() {
		// Não é necessário testar o fluxo excepcional, isto é,
        // quando durante a coação a jarra é retirada obrigando
        // a cafeteira a abrir a válvula de segurança

	}
	
	@AfterClass
	public static void bringDown() {
        // Este método atribui null aos objetos de interesse
        // permitindo que o coletor de lixo atue

		h = null;
		c = null;
	}

}
