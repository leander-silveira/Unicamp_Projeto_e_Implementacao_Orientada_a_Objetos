package br.com.voidstar.personCompany;

public class Company {
	private String name;
	private int employeeCount;


    public Company() {
    	name = "";
    	employeeCount = 0;   	
    }

    public Company(String name) {
    	this.name = name;
    	this.employeeCount = 0;
    }

    public String getName() {
    	return name;
    }

    public void setName(String name) {
    	this.name = name;
    }

    public int getNumberOfEmployees() {
    	return employeeCount;
    }

    public void setNumberOfEmployees(int numberOfEmployees) {
    	//if(numberOfEmployees >= 0) {
    		this.employeeCount = numberOfEmployees;
    	//}
    }

    public void incrementNumberOfEmployees() {
    	employeeCount++;
    }

    public void decrementNumberOfEmployees() {
    	if(employeeCount > 0) {
    		employeeCount--;
    	}
    }
}