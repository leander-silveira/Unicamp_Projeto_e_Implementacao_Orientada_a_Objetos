package inf319;

import junit.framework.TestCase;

public class ProgressaoTest extends TestCase { 

    public void testProgressaoAritmetica() {
        Progressao p = new ProgressaoAritmetica();
        assertEquals(0, p.inicia());
        assertEquals(1, p.proxTermo());
        assertEquals(2, p.proxTermo());
        assertEquals(4, p.iesimoTermo(4));
        assertEquals(6, p.iesimoTermo(6));
        assertEquals("0 1 2 3 4 5 6 7 8 9 10\n",
                     p.imprimeProgressao(10));

        p = new ProgressaoAritmetica(5);
        assertEquals(0, p.inicia());
        assertEquals(5, p.proxTermo());
        assertEquals(10, p.proxTermo());
        assertEquals(20, p.iesimoTermo(4));
        assertEquals(30, p.iesimoTermo(6));
        assertEquals("0 5 10 15 20 25 30 35 40 45 50\n",
                     p.imprimeProgressao(10));
    }

    public void testProgressaoGeometrica() {
        Progressao p = new ProgressaoGeometrica();
        assertEquals(1, p.inicia());
        assertEquals(2, p.proxTermo());
        assertEquals(4, p.proxTermo());
        assertEquals(16, p.iesimoTermo(4));
        assertEquals(64, p.iesimoTermo(6));
        assertEquals("1 2 4 8 16 32 64 128 256 512 1024\n",
                     p.imprimeProgressao(10));

        p = new ProgressaoGeometrica(5);
        assertEquals(1, p.inicia());
        assertEquals(5, p.proxTermo());
        assertEquals(25, p.proxTermo());
        assertEquals(625, p.iesimoTermo(4));
        assertEquals(15625, p.iesimoTermo(6));
        assertEquals("1 5 25 125 625 3125 15625 78125 390625 1953125 9765625\n",
                     p.imprimeProgressao(10));
    }
    
    public void testProgressaoFibonacci() {
        Progressao p = new ProgressaoFibonacci();
        assertEquals(0, p.inicia());
        assertEquals(1, p.proxTermo());
        assertEquals(1, p.proxTermo());
        assertEquals(3, p.iesimoTermo(4));
        assertEquals(8, p.iesimoTermo(6));
        assertEquals("0 1 1 2 3 5 8 13 21 34 55\n",
                     p.imprimeProgressao(10));
    }

    public void testProgressaoJosephus() {
        Progressao p = new ProgressaoJosephus();
        assertEquals(0, p.inicia());
        assertEquals(2, p.proxTermo());
        assertEquals(4, p.proxTermo());
        assertEquals(8, p.iesimoTermo(4));
        assertEquals(12, p.iesimoTermo(6));
        assertEquals("0 2 4 6 8 10 12 14 16 18 20\n",
                     p.imprimeProgressao(10));
        assertEquals(17, p.iesimoTermo(40));
        assertEquals(0, p.iesimoTermo(41));
        

        p = new ProgressaoJosephus(41, 10);
        assertEquals(0, p.inicia());
        assertEquals(10, p.proxTermo());
        assertEquals(20, p.proxTermo());
        assertEquals(30, p.proxTermo());
        assertEquals(40, p.proxTermo());
        assertEquals(11, p.proxTermo());
        assertEquals(40, p.iesimoTermo(4));
        assertEquals(22, p.iesimoTermo(6));
        assertEquals("0 10 20 30 40 11 22 33 4 16 28\n",
                     p.imprimeProgressao(10));
        assertEquals(25, p.iesimoTermo(40));
        assertEquals(0, p.iesimoTermo(41));
    }
 
    // A sua solução de cache (Progressao rápida) deve passar nos
    // testes unitários abaixo.
    // Assim que tiver implementado a sua solução, substitua a elipse (...)
    // por uma instanciação da sua solução
    // remova os comentários e verifique se a sua solução está correta.
    
    public void testProgressaoRapida() {
        Progressao p = new ProgressaoAritmetica(); // solução com cache
        Progressao q = new ProgressaoAritmetica();

        // Cache é aquecido
        int it = p.iesimoTermo(1000);

        // Mede o tempo de cálculo com cache
        long pt = System.nanoTime();
        it = p.iesimoTermo(1000);
        pt = System.nanoTime() - pt;

        // Mede o tempo de cálculo sem cache
        long bt = System.nanoTime();
        int iq = q.iesimoTermo(1000);
        bt = System.nanoTime() - bt;

        // Verifica se a versão com cache é mais rápida
        assertTrue(bt > pt);

        // Teste para ProgressaoGeometrica
        p = new ProgressaoGeometrica();
        q = new ProgressaoGeometrica();
        it = p.iesimoTermo(2000);

        pt = System.nanoTime();
        it = p.iesimoTermo(2000);
        pt = System.nanoTime() - pt;

        bt = System.nanoTime();
        iq = q.iesimoTermo(2000);
        bt = System.nanoTime() - bt;

        assertTrue(bt > pt);

        // Teste para ProgressaoFibonacci
        p = new ProgressaoFibonacci();
        q = new ProgressaoFibonacci();
        it = p.iesimoTermo(2000);

        pt = System.nanoTime();
        it = p.iesimoTermo(2000);
        pt = System.nanoTime() - pt;

        bt = System.nanoTime();
        iq = q.iesimoTermo(2000);
        bt = System.nanoTime() - bt;

        assertTrue(bt > pt);
    }
    
}


// A sua solução de cache (Progressao rápida) deve passar nos
// testes unitários abaixo.
// Assim que tiver implementado a sua solução, substitua a elipse (...)
// por uma instanciação da sua solução
// remova os comentários e verifique se a sua solução está correta.

// public void testProgressaoRapida() {
//     Progressao p = new ... // instanciação da sua solução rápida
//     Progressao q = new ProgressaoAritmetica(); // new
//
//     // cache é aquecido, isto é, inicializado
//     // com o cálculo de 1000 termos
//     int it = p.iesimoTermo(1000);
//    // com o cache pronto
//    // mede-se o tempo de cálculo do milésimo termo
// 	    long pt = System.nanoTime();
// 	    it = p.iesimoTermo(1000);
//     pt = System.nanoTime() - pt;
//    // calcula-se o tempo de cálculo do milésimo termo
//    // para a implementação original
//     long bt = System.nanoTime();
//     int iq = q.iesimoTermo(1000);
//     bt = System.nanoTime() - bt;
//    // compara-se os tempos
//     assertTrue(bt > pt);
//   // testes comparativos para os outros métodos
//   // da progressão rápida (cache) e original.
//     q.iesimoTermo(100);
//     assertEquals(0, p.inicia());
//     assertEquals(1, p.proxTermo());
//     assertEquals(2, p.proxTermo());
//     assertEquals(4, p.iesimoTermo(4));
//     assertEquals(6, p.iesimoTermo(6));
//     assertEquals("0 1 2 3 4 5 6 7 8 9 10\n",
//                  p.imprimeProgressao(10));

//     p = new ... // instanciação da sua solução rápida
//     q = new ProgressaoGeometrica();
//     it = p.iesimoTermo(2000);
//     pt = System.nanoTime();
//     it = p.iesimoTermo(2000);
//     pt = System.nanoTime() - pt;
//     bt = System.nanoTime();
//     iq = q.iesimoTermo(2000);
//     bt = System.nanoTime() - bt;
//     assertTrue(bt > pt);
//     assertEquals(1, p.inicia());
//     assertEquals(2, p.proxTermo());
//     assertEquals(4, p.proxTermo());
//     assertEquals(16, p.iesimoTermo(4));
//     assertEquals(64, p.iesimoTermo(6));
//     assertEquals("1 2 4 8 16 32 64 128 256 512 1024\n",
//                  p.imprimeProgressao(10));
    
//     p = new ... // instanciação da sua solução rápida
//     q = new ProgressaoFibonacci();
//     it = p.iesimoTermo(2000);
//     pt = System.nanoTime();
//     it = p.iesimoTermo(2000);
//     pt = System.nanoTime() - pt;
//     bt = System.nanoTime();
//     iq = q.iesimoTermo(2000);
//     bt = System.nanoTime() - bt;
//     assertTrue(bt > pt);
//     assertEquals(0, p.inicia());
//     assertEquals(1, p.proxTermo());
//     assertEquals(1, p.proxTermo());
//     assertEquals(3, p.iesimoTermo(4));
//     assertEquals(8, p.iesimoTermo(6));
//     assertEquals("0 1 1 2 3 5 8 13 21 34 55\n",
//                  p.imprimeProgressao(10));

//     p = new ... // instanciação da sua solução rápida
//     assertEquals(0, p.inicia());
//     assertEquals(2, p.proxTermo());
//     assertEquals(4, p.proxTermo());
//     assertEquals(8, p.iesimoTermo(4));
//     assertEquals(12, p.iesimoTermo(6));
//     assertEquals("0 2 4 6 8 10 12 14 16 18 20\n",
//                  p.imprimeProgressao(10));
//     assertEquals(17, p.iesimoTermo(40));
//     assertEquals(0, p.iesimoTermo(41));
    
//     g = new ... // instanciação da sua solução rápida
//     Progressao j = new ProgressaoAritmetica();
//     j.iesimoTermo(1000);
//     long ta = System.nanoTime();
//     j.iesimoTermo(1000);
//     ta = System.nanoTime() - ta;
    
//     g.iesimoTermo(1000);        
//     long tb = System.nanoTime();
//     g.iesimoTermo(1000);
//     tb = System.nanoTime() - tb;
//     assertTrue(ta > tb);
    
    
// }


