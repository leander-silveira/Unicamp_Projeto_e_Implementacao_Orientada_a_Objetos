package inf319;

public class ProgressaoFibonacci extends Progressao {

    private int valPrev;

    public ProgressaoFibonacci() {
        inicia();
    }

    public int inicia() {
        valCor = 0;
        valPrev = 1;
        return valCor;
    }

    public int proxTermo() {
        int next = valCor + valPrev;
        valPrev = valCor;
        valCor = next;
        return valCor;
    }
}
