package inf319;

import java.util.HashMap;

public abstract class Progressao {

    protected int valCor;
    private HashMap<Integer, Integer> cache;

    public Progressao() {
        cache = new HashMap<>();
    }

    public abstract int inicia();

    public abstract int proxTermo();

    public int iesimoTermo(int i) {
        // Verifica se o termo já está no cache
        if (cache.containsKey(i)) {
            return cache.get(i);
        }

        // Se não estiver no cache, calcula e armazena
        int iesimo = inicia();
        cache.put(0, iesimo); // Termo inicial

        for (int j = 1; j <= i; j++) {
            iesimo = proxTermo();
            cache.put(j, iesimo); // Armazena cada termo calculado
        }

        return iesimo;
    }

    public String imprimeProgressao(int n) {
        StringBuilder progressao = new StringBuilder();
        progressao.append(iesimoTermo(0));

        for (int j = 1; j <= n; j++) {
            progressao.append(' ');
            progressao.append(iesimoTermo(j)); // Usa o cache
        }

        progressao.append('\n');
        return progressao.toString();
    }
}
