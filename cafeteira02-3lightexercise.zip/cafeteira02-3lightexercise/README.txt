Project Name: Cafeteira
Author: Luiz Eduardo Buzato
================================

Cafeteira is part of the material  given to the students of the course
INF319-Object Oriented Design and Implementation of the Specialization
on Software Engineering offered by the Institute of Computing/UNICAMP.

Cafeteira is free  software, licensed under the GNU GPL  (see the file
"LICENSE.txt", or visit the site http://www.gnu.org/licenses/).

For usage instructions and build dependencies read "NOTICE.txt".

Copyright © 1998-2014 Luiz Eduardo Buzato

Copying and distribution  of this file, with  or without modification,
are permitted  in any  medium without  royalty provided  the copyright
notice and this notice are preserved.
