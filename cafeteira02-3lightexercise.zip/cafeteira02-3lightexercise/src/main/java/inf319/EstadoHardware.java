package inf319;
// Arquivo EstadoHardware.java
public class EstadoHardware {
    public static final EstadoHardware ebulidorLigado = new EstadoHardware(0);
    public static final EstadoHardware ebulidorDesligado = new EstadoHardware(1);
    public static final EstadoHardware placaQuente = new EstadoHardware(2);
    public static final EstadoHardware placaFria = new EstadoHardware(3);
    public static final EstadoHardware valvulaAberta = new EstadoHardware(4);
    public static final EstadoHardware valvulaFechada = new EstadoHardware(5);
    public static final EstadoHardware jarraNoLugar = new EstadoHardware(6);
    public static final EstadoHardware jarraRemovida = new EstadoHardware(7);
    public static final EstadoHardware indicadoraDesligada = new EstadoHardware(8);
    public static final EstadoHardware indicadoraLigada = new EstadoHardware(9);
    public static final EstadoHardware indicadoraAmarelo = new EstadoHardware(10);
    public static final EstadoHardware indicadoraVermelho = new EstadoHardware(11);
    public static final EstadoHardware estado12 = new EstadoHardware(12);
    public static final EstadoHardware estado13 = new EstadoHardware(13);
    public static final EstadoHardware estado14 = new EstadoHardware(14);

    // Adicionando novos estados a partir do ID 15
    public static final EstadoHardware indicadoraAzul = new EstadoHardware(15);
    public static final EstadoHardware indicadoraRoxo = new EstadoHardware(16);
    public static EstadoHardware aquecedorDesligado;
    public static EstadoHardware jarraVazia;
    public static EstadoHardware aquecedorLigado;
    public static EstadoHardware placaVazia;
    public static EstadoHardware jarraNaoVazia;
    public static EstadoHardware ebulidorVazio;
    public static EstadoHardware interruptorSolto;
    public static EstadoHardware indicadoraCoacao;
    public static EstadoHardware interruptorPressionado;
    public static EstadoHardware ebulidorNaoVazio;

    private int id;

    private EstadoHardware(int id) {
        this.id = id;
    }

    public boolean equals(Object obj) {
        return (obj != null) && (obj instanceof EstadoHardware) && ((EstadoHardware) obj).id == id;
    }
}
