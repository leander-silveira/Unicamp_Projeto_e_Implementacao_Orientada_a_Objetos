package engsoft;

/**
 * Classe Cafeteira implementa o controle do funcionamento da cafeteira Harar.
 */
public class Cafeteira {

    private Hardware hardware;

    public Cafeteira(Hardware hardware) {
        this.hardware = hardware;
    }

    /**
     * Inicia o ciclo de preparo do café.
     */
    public void iniciarPreparo() {
        // Verifica se há água no reservatório do ebulidor
        if (hardware.leEstadoEbulidor().equals(EstadoHardware.ehEbulidorVazio)) {
            System.out.println("Erro: Não há água suficiente no reservatório.");
            return;
        }

        // Verifica se a jarra está na placa
        EstadoHardware estadoJarra = hardware.leEstadoAquecedor();
        if (estadoJarra.equals(EstadoHardware.ehPlacaVazia)) {
            System.out.println("Erro: A jarra não está posicionada.");
            return;
        }

        // Liga o ebulidor
        hardware.atuEstadoElementoEbulidor(EstadoHardware.ehEbulidorLigado);
        // Fecha a válvula de pressão para iniciar o fluxo de vapor
        hardware.atuValvulaPressao(EstadoHardware.ehValvulaFechada);

        // Monitora o processo
        while (!hardware.leEstadoEbulidor().equals(EstadoHardware.ehEbulidorVazio)) {
            hardware.executa();
        }

        // Desliga o ebulidor após uso
        hardware.atuEstadoElementoEbulidor(EstadoHardware.ehEbulidorDesligado);

        // Liga o aquecedor se a jarra contiver café
        if (hardware.pegaNivelDeCafe() > 0) {
            hardware.atuElementoAquecedor(EstadoHardware.ehAquecedorLigado);
        }

        // Acende a luz indicadora para indicar que o café está pronto
        hardware.atuLuzIndicadora(EstadoHardware.ehIndicadoraLigada);

        System.out.println("Café pronto!");
    }

    /**
     * Finaliza o ciclo de preparo e reseta os estados.
     */
    public void finalizarPreparo() {
        // Desliga todos os componentes
        hardware.atuEstadoElementoEbulidor(EstadoHardware.ehEbulidorDesligado);
        hardware.atuValvulaPressao(EstadoHardware.ehValvulaAberta);
        hardware.atuElementoAquecedor(EstadoHardware.ehAquecedorDesligado);
        hardware.atuLuzIndicadora(EstadoHardware.ehIndicadoraDesligada);

        System.out.println("Ciclo de preparo finalizado.");
    }

    /**
     * Simula a retirada da jarra durante o preparo do café.
     */
    public void removerJarra() {
        hardware.removeJarra();
        hardware.atuValvulaPressao(EstadoHardware.ehValvulaAberta);
        System.out.println("Jarra removida. Fluxo interrompido.");
    }

    /**
     * Simula a recolocação da jarra.
     */
    public void recolocarJarra() {
        hardware.colocaJarra();
        hardware.atuValvulaPressao(EstadoHardware.ehValvulaFechada);
        System.out.println("Jarra recolocada. Fluxo retomado.");
    }

    /**
     * Método principal para testar o funcionamento da classe Cafeteira.
     */
    public static void main(String[] args) {
        // Instancia o hardware e a cafeteira
        Hardware hardware = new Hardware(false);
        Cafeteira cafeteira = new Cafeteira(hardware);

        // Inicializa o hardware
        hardware.iniciar();

        // Ajusta os níveis iniciais de água e café
        hardware.ajustaNivelDeAgua(20);
        hardware.colocaJarra();

        // Inicia o preparo do café
        cafeteira.iniciarPreparo();

        // Finaliza o preparo
        cafeteira.finalizarPreparo();
    }
}
