package engsoft.prova4;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContratosDeTrabalho {

    /*
     * Considerações sobre o Projeto Orientado a Objetos
     *
     * Esta classe serve como uma ponte entre as classes APessoa e ACompanhia.
     * Essa ponte é importante porque centraliza a responsabilidade de cálculo
     * dos custos e salários, promovendo melhor encapsulamento e separação de responsabilidades.
     */

    private Map<APessoa, Set<Contrato>> contratosEmpregados;
    private Map<ACompanhia, Set<Contrato>> contratosEmpregadores;

    public ContratosDeTrabalho() {
        contratosEmpregados = new java.util.HashMap<>();
        contratosEmpregadores = new java.util.HashMap<>();
    }

    public Set<ACompanhia> getEmpregadores(APessoa empregado) {
        Set<Contrato> contratos = contratosEmpregados.get(empregado);
        Set<ACompanhia> empregadores = new HashSet<>();
        if (contratos != null) {
            for (Contrato contrato : contratos) {
                empregadores.add(contrato.getEmpregador());
            }
        }
        return empregadores;
    }

    public Set<APessoa> getEmpregados(ACompanhia empregador) {
        Set<Contrato> contratos = contratosEmpregadores.get(empregador);
        Set<APessoa> empregados = new HashSet<>();
        if (contratos != null) {
            for (Contrato contrato : contratos) {
                empregados.add(contrato.getEmpregado());
            }
        }
        return empregados;
    }

    public Set<Contrato> getContratos(ACompanhia companhia) {
        return contratosEmpregadores.getOrDefault(companhia, new HashSet<>());
    }

    public Set<Contrato> getContratosPorPessoa(APessoa pessoa) {
        return contratosEmpregados.getOrDefault(pessoa, new HashSet<>());
    }

    public double custoTotal(ACompanhia companhia) {
        double total = 0.0;
        Set<Contrato> contratos = contratosEmpregadores.get(companhia);
        if (contratos != null) {
            for (Contrato contrato : contratos) {
                total += contrato.getSalario();
            }
        }
        return total;
    }

    public double salarioTotal(APessoa pessoa) {
        double total = 0.0;
        Set<Contrato> contratos = contratosEmpregados.get(pessoa);
        if (contratos != null) {
            for (Contrato contrato : contratos) {
                total += contrato.getSalario();
            }
        }
        return total;
    }

    public void emprega(ACompanhia companhia, APessoa pessoa, double salario) {
        Contrato contrato = new Contrato(companhia, pessoa, salario);

        contratosEmpregados.computeIfAbsent(pessoa, k -> new HashSet<>()).add(contrato);
        contratosEmpregadores.computeIfAbsent(companhia, k -> new HashSet<>()).add(contrato);
    }

    public void demite(ACompanhia companhia, APessoa pessoa) {
        Set<Contrato> contratosPessoa = contratosEmpregados.get(pessoa);
        if (contratosPessoa != null) {
            contratosPessoa.removeIf(contrato -> contrato.getEmpregador().equals(companhia));
            if (contratosPessoa.isEmpty()) {
                contratosEmpregados.remove(pessoa);
            }
        }

        Set<Contrato> contratosCompanhia = contratosEmpregadores.get(companhia);
        if (contratosCompanhia != null) {
            contratosCompanhia.removeIf(contrato -> contrato.getEmpregado().equals(pessoa));
            if (contratosCompanhia.isEmpty()) {
                contratosEmpregadores.remove(companhia);
            }
        }
    }
}
