package engsoft.prova4;

import java.util.Set;

public class APessoa {

    /*
     * Considerações sobre o Projeto Orientado a Objetos
     *
     * Esta classe representa uma pessoa associada a contratos de trabalho.
     * Ela depende da classe ContratosDeTrabalho para acessar os contratos associados.
     */

    private ContratosDeTrabalho contratosDeTrabalho; // Referência para acessar contratos

    public APessoa(ContratosDeTrabalho contratosDeTrabalho) {
        this.contratosDeTrabalho = contratosDeTrabalho;
    }

    /**
     * Calcula o salário total recebido pela pessoa.
     * Utiliza os contratos associados na instância de ContratosDeTrabalho.
     *
     * @return O salário total recebido pela pessoa.
     */
    public double getSalarioTotal() {
        double total = 0.0;
        Set<Contrato> contratos = contratosDeTrabalho.getContratosPorPessoa(this);
        if (contratos != null) {
            for (Contrato contrato : contratos) {
                total += contrato.getSalario();
            }
        }
        return total;
    }
}
