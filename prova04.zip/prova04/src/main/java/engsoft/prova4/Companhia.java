package engsoft.prova4;

import java.util.HashSet;
import java.util.Set;

public class Companhia {

    /*
     *  Considerações sobre o Projeto Orientado a Objetos
     *
     */

    private Set<Pessoa> empregados;

    public Companhia() {
        empregados = new HashSet<>(); // Tipo genérico explicitado
    }

    public void emprega(Pessoa empregado, double salario) {
        empregado.emprega(this, salario);
        empregados.add(empregado);
    }

    public void demite(Pessoa empregado) {
        empregado.demite();
        empregados.remove(empregado);
    }

    public double custoTotal() {
        double custo = 0;
        for (Pessoa empregado : empregados) { // Iteração com for-each
            custo += empregado.getSalario();
        }
        return custo;
    }
}
