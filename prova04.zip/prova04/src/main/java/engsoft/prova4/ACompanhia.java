package engsoft.prova4;

import java.util.Set;

public class ACompanhia {

    /*
     *  Considerações sobre o Projeto Orientado a Objetos
     *
     */

    private ContratosDeTrabalho contratos;

    public ACompanhia(ContratosDeTrabalho contratos) {
        this.contratos = contratos;
    }

    public void emprega(APessoa empregado, double salario) {
        contratos.emprega(this, empregado, salario);
    }

    public void demite(APessoa empregado) {
        contratos.demite(this, empregado);
    }

    public double custoTotal() {
        double custo = 0.0;
        Set<Contrato> contratosCompanhia = contratos.getContratos(this);
        if (contratosCompanhia != null) {
            for (Contrato contrato : contratosCompanhia) {
                custo += contrato.getSalario();
            }
        }
        return custo;
    }
}
