package engsoft.prova4;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ContratosDeTrabalhoTest {
    ContratosDeTrabalho ct = null;
    ACompanhia ca = null, cb = null;
    APessoa a = null, b = null;
    APessoa c = null, d = null;

    @Before
    public void setUp() throws Exception {
        ct = new ContratosDeTrabalho();
        ca = new ACompanhia(ct);
        cb = new ACompanhia(ct);
        a = new APessoa(ct);
        b = new APessoa(ct);
        c = new APessoa(ct);
        d = new APessoa(ct);
    }

    @Test
    public void ContratosTest() {

        ct.emprega(ca, a, 1000.00);
        ct.emprega(ca, b, 1000.00);
        ct.emprega(ca, c, 1000.00);
        ct.emprega(cb, a, 1000.00);
        ct.emprega(cb, d, 1000.00);
        assertEquals(3000.00, ca.custoTotal(), 0.0);
        assertEquals(2000.00, cb.custoTotal(), 0.0);
        assertEquals(2000.00, a.getSalarioTotal(), 0.0);
        ct.demite(cb, a);
        assertEquals(1000.00, cb.custoTotal(), 0.0);
        assertEquals(1000.00, a.getSalarioTotal(), 0.0);
        
    }
}
