package engsoft.prova4;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CompanhiaTest {



    Pessoa a = null;
    Pessoa b = null;
    Pessoa c = null;
    Companhia cc = null;

    @Before
    public void setUp() throws Exception {
       a = new Pessoa();
       b = new Pessoa();
       c = new Pessoa();
       cc = new Companhia();
    }

    @Test
    public void CompanhiaSalarioTest() {
        a.emprega(cc, 1000.00);
        cc.emprega(a, 1000.00);
        b.emprega(cc, 1500.00);
        cc.emprega(b, 1500.00);
        cc.emprega(c, 3000.00);
        c.emprega(cc, 3000.00);
        assertEquals(1000.00, a.getSalario(), 0.0);
        assertEquals(5500.00, cc.custoTotal(), 0.0);

        cc.emprega(a, 2000.00);
        assertEquals(2000.00, a.getSalario(), 0.0);
        assertEquals(6500.00, cc.custoTotal(), 0.0);
    }
}
