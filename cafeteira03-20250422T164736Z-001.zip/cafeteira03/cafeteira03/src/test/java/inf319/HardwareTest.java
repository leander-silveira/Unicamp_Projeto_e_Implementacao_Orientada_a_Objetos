package inf319;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HardwareTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
//		fail("Implemente aqui o teste para o novo Hardware, se necessario.");
	}

}
