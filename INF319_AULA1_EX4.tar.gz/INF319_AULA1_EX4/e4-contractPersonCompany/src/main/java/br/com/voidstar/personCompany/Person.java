package br.com.voidstar.personCompany;

public class Person {
	private String name;
    private String surname;
    private Contract contract;
    
    public Person() {
        this.name = "";
        this.surname = "";       
    }

    public Person(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }
    
    public Person(String name, String surname, double salary, Company company) {
        this.name = name;
        this.surname = surname;
        if (company != null) {
            company.hire(this, salary);
        }
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public double getSalary() {
        return contract != null ? contract.getSalary() : 0.0;
    }

    public Company getCompany() {
        return contract != null ? contract.getCompany() : null;
    }

    protected void selfHire(Contract contract) {
        this.contract = contract;
    }
    
    public void selfHire(Company company, double salary) {
        if (this.contract == null || this.contract.getCompany() != company) {
            if (this.contract != null) {
                selfDismiss(this.contract);
            }
            company.hire(this, salary);
        }
    }

    protected void selfDismiss(Contract contract) {
        if (this.contract != null && this.contract.equals(contract)) {
            this.contract = null;
        }
    }
    
    public void selfDismiss(Company company) {
        if (this.contract != null && this.contract.getCompany().equals(company)) {
            company.dismiss(this);
            this.contract = null;
        }        
    }
}
